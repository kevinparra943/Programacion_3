/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quiz;

/**
 *
 * @author Estudiante
 */
public class cuentaEmpleado extends cuentaBancaria {
    
     public String nivel;
   
      public void setsaldo(float a){
       saldo = a;
    }
}
