/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quiz;

/**
 *
 * @author Estudiante
 */
public class Quiz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int a=9;
     
       cuentaEmpleado empleado1 = new cuentaEmpleado();
       cuentaDirectivos directivo1 = new cuentaDirectivos();
       cuentaDirectivos directivo2 = new cuentaDirectivos();
     
    empleado1.nivel="c";
    empleado1.saldo=10000;
    
    directivo2.consignar(a, 45000);
    }
    
}
