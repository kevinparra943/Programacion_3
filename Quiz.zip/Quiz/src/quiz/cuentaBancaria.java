/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quiz;

/**
 *
 * @author Estudiante
 */
public class cuentaBancaria {
    
    private int clave;
   public float saldo;
    
     public void retirar(int a, float b){
         if (a==clave){
             saldo=saldo-b;
         }
        
     }
     public void consignar(int a,float b){
        
          if (a==clave){
            saldo=saldo+b;
         }
     }
     public void cambiarClave(int a, int b){
        if (a==clave){
           clave=b;
         }
         
     }
}
